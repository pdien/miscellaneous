let food = "water bottles,meal packs,snacks,chocolate";
let equipment = "space suits,jet packs,tool belts,thermal detonators";
let pets = "parrots,cats,moose,alien eggs";
let sleepAids = "blankets,pillows,eyepatches,alarm clocks";

//a) Use split to convert the strings into four cabinet arrays. Alphabetize the contents of each cabinet.
food = food.split(",").sort();
equipment = equipment.split(",").sort();
pets = pets.split(",").sort();
sleepAids = sleepAids.split(",").sort();

//b) Initialize a cargoHold array and add the cabinet arrays to it. Print cargoHold to verify its structure.
cargoHold = {
  "food": food,
  "equipment": equipment,
  "pets": pets,
  "sleepAids": sleepAids
};
let titles = {
  0: "food",
  1: "equipment",
  2: "pets",
  3: "sleepAids"
};
console.log(cargoHold);


//c) Query the user to select a cabinet (0 - 3) in the cargoHold.

//const input = require('readline-sync');
let item = prompt('Select a cabinet (0 - 3) in the cargo hold: ');


//d) Use bracket notation and a template literal to display the contents of the selected cabinet. If the user entered an invalid number, print an error message.
if (item <= 3){
  console.log(cargoHold[titles[item]]);
} else {
  console.log(`Error`);
}


//e) Modify the code to query the user for BOTH a cabinet in cargoHold AND a particular item. Use the 'includes' method to check if the cabinet contains the selected item, then print “Cabinet ____ DOES/DOES NOT contain ____.”

let cabinet = prompt(`${Object.keys(cargoHold)}\nSelect a cabinet: `);
let item4 = prompt(`${Object.values(cargoHold)}\nSelect an item:`);
// let item4 = prompt(`${cargoHold[titles[item]]}\nSelect an item:`);
if (!cargoHold[cabinet].includes(item4)){
   console.log(`Cabinet ${cabinet} DOES NOT contain ${item4}`);
} else {
  console.log(`Cabinet ${cabinet} DOES contain ${item4}`);
}